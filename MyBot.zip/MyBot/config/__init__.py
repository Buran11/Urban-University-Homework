__all__ = ['cfg_admin', 'cfg_token', 'cfg_keyboards']
