from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

kb_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text='Playstation Plus 3 месяца', callback_data='plus_3'),
        ],
        [
            InlineKeyboardButton(
                text='Playstation Plus 12 месяца', callback_data='plus_12'),
        ],
        [
            InlineKeyboardButton(
                text='Playstation Store 1000 рублей', callback_data='store_1000'),
        ],
        [
            InlineKeyboardButton(
                text='Playstation Store 2500 рублей', callback_data='store_2500'),
        ],
        [
            InlineKeyboardButton(
                text='Playstation Store 4000 рублей', callback_data='store_4000'),
        ],
        [
            InlineKeyboardButton(text='Информация', callback_data='info'),
        ]
    ],
    resize_keyboard=True
)

kb_back = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='Назад', callback_data='back'),
        ]
    ],
    resize_keyboard=True
)

kb_buy = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='Купить', callback_data='buy'),
        ],
        [
            InlineKeyboardButton(text='Назад', callback_data='back'),
        ]
    ],
    resize_keyboard=True
)
