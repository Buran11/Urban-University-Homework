import config.cfg_keyboards
from aiogram.types import InputMediaPhoto
from databases import db_catalog_orm as catalog


# RU: Содержимое карточки продукта
# EU: The contents of the product card
async def product_info(call, image, productname, ):
    description = catalog.get_product_description(
        catalog.get_product_name(productname))
    price = f'ЦЕНА: {catalog.get_product_price(catalog.get_product_name(productname))} рублей.\n'

    with open(f'files/media/{image}.png', 'rb') as photo:
        mes = InputMediaPhoto(
            media=photo, caption=description + '\n' + price, parse_mode='HTML')
        await call.message.edit_media(media=mes, reply_markup=config.cfg_keyboards.kb_buy)
    await call.answer()
