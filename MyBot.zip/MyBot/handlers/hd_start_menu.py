import texts.txt_start
from texts import txt_products_info
import config.cfg_keyboards
from handlers import hd_product_menu as product


# RU: Содержимое стартового меню
# EU: The contents of the start menu
async def start_menu(message):
    with open('files/media/start_menu.png', 'rb') as photo:
        await message.answer_photo(photo, caption=texts.txt_start.start, parse_mode='HTML', reply_markup=config.cfg_keyboards.kb_menu)


# RU: Активные вкладки (кнопки) в стартовом меню с карточкой продукта
# EU: Active tabs (buttons) in the start menu with a product card
async def plus_3(call):
    await product.product_info(call, 'plus_3', txt_products_info.name_plus_3)


async def plus_12(call):
    await product.product_info(call, 'plus_12', txt_products_info.name_plus_12)


async def store_1000(call):
    await product.product_info(call, 'store_1000', txt_products_info.name_store_1000)


async def store_2500(call):
    await product.product_info(call, 'store_2500', txt_products_info.name_store_2500)


async def store_4000(call):
    await product.product_info(call, 'store_4000', txt_products_info.name_store_4000)
