import texts.txt_info
import texts.txt_discount
import config.cfg_keyboards
from aiogram.types import InputMediaPhoto


# RU: Содержимое информационного меню
# EU: The contents of the information menu
async def info_menu(call):
    with open('files/media/discount_10.png', 'rb') as photo:
        mes = InputMediaPhoto(
            media=photo, caption=texts.txt_discount.discount + '\n\n' + texts.txt_info.info, parse_mode='HTML')
        await call.message.edit_media(media=mes, reply_markup=config.cfg_keyboards.kb_back)
    await call.answer()
