import texts.txt_start
import config.cfg_keyboards
from aiogram.types import InputMediaPhoto


# RU: Приветствие
# EU: Greeting
async def echo(message):
    await message.answer(f'Здравствуйте, {message.from_user.first_name}. ' + texts.txt_start.echo)


# RU: Активная вкладка (кнопка) 'Назад'
# EU: Active tab (button) 'Back'
async def back(call):
    with open('files/media/start_menu.png', 'rb') as photo:
        mes = InputMediaPhoto(
            media=photo, caption=texts.txt_start.start, parse_mode='HTML')
        await call.message.edit_media(media=mes, reply_markup=config.cfg_keyboards.kb_menu)
    await call.answer()


# RU: Активная вкладка (кнопка) 'Купить'
# EU: Active tab (button) 'Buy'
async def buy(call):
    await call.message.answer('https://https://www.tbank.ru/')
    await call.answer()
