from aiogram import Bot, Dispatcher, executor
from config import *
from handlers import hd_start_menu as start
from handlers import *
from databases import db_adding_to_catalog


# RU: Подключение к токену бота
# EU: Connection to the bot token
api = cfg_token.BOT_API_TOKEN
bot = Bot(token=api)
dp = Dispatcher(bot)


# RU: Регистрация хендлеров
# EU: Registration of handlers
dp.message_handler(text='/start')(start.start_menu)
dp.callback_query_handler(text='plus_3')(start.plus_3)
dp.callback_query_handler(text='plus_12')(start.plus_12)
dp.callback_query_handler(text='store_1000')(start.store_1000)
dp.callback_query_handler(text='store_2500')(start.store_2500)
dp.callback_query_handler(text='store_4000')(start.store_4000)

dp.callback_query_handler(text='info')(hd_info_menu.info_menu)

dp.callback_query_handler(text='buy')(hd_other.buy)
dp.callback_query_handler(text='back')(hd_other.back)
dp.message_handler()(hd_other.echo)


if __name__ == "__main__":
    # RU: Добавление продуктов в таблицу Catalog
    # EU: Adding products to the Catalog table
    db_adding_to_catalog.adding_to_catalog()

    # RU: Запуск бота
    # EU: Start the bot
    executor.start_polling(dp, skip_updates=True)
