__all__ = [
    'txt_start',
    'txt_info',
    'txt_discount',
    'txt_products_info'
]
