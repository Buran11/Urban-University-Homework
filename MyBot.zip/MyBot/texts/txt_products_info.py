# RU: Тексты для карточек продуктов
# EU: Texts for product cards
name_store_1000 = 'Playstation Store 1000'
description_store_1000 = """Пополнение кошелька на 1000 рублей в Playstation Store\n"""
price_store_1000 = 1000

name_store_2500 = 'Playstation Store 2500'
description_store_2500 = """Пополнение кошелька на 2500 рублей в Playstation Store\n"""
price_store_2500 = 2500

name_store_4000 = 'Playstation Store 4000'
description_store_4000 = """Пополнение кошелька на 4000 рублей в Playstation Store\n"""
price_store_4000 = 4000

name_plus_3 = 'Playstation Plus 3'
description_plus_3 = """Оформить подписку Playstation Plus на 3 месяца\n"""
price_plus_3 = 3000

name_plus_12 = 'Playstation Plus 12'
description_plus_12 = """Оформить подписку Playstation Plus на 12 месяцев\n"""
price_plus_12 = 8000
