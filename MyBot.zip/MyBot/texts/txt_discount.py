# RU: Тексты для информационного меню со скидкой
# EU: Texts for the information menu with a discount
discount = """СКИДКА 10%,  если вы покупаете два и более продукта!!!\n\n"""
