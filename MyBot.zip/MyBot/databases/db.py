import sqlite3


# RU: Подключение к базе данных
# EU: Connection to the database
connect = sqlite3.connect('files/database.db')
cursor = connect.cursor()


# RU: Создание таблицы Catalog
# EU: Creating the Catalog table
cursor.execute("""CREATE TABLE IF NOT EXISTS Catalog(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    productname TEXT NOT NULL,
    description TEXT NOT NULL,
    price INT NOT NULL
)""")
