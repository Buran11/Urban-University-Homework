from databases.db import cursor, connect


# RU: Проверка наличия продукта в каталоге
# EU: Checking the presence of a product in the catalog
def validate_product(productname):
    check_product = cursor.execute(
        "SELECT * FROM Catalog WHERE productname = ?", (productname,)).fetchone()
    if check_product is not None:
        return True
    else:
        return False


# RU: Добавление продукта в каталог
# EU: Adding a product to the catalog
def add_product(productname, description, price):
    if (validate_product(productname)):
        return
    cursor.execute(
        "INSERT INTO Catalog(productname, description, price) VALUES(?, ?, ?)", (productname, description, price))
    connect.commit()


# RU: Взять имя продукта из таблицы Catalog
# EU: Take the product name from the Catalog table
def get_product_name(productname):
    return cursor.execute(
        "SELECT productname FROM Catalog WHERE productname = ?", (productname,)).fetchone()[0]


# RU: Взять описание продукта из таблицы Catalog
# EU: Take the product description from the Catalog table
def get_product_description(productname):
    return cursor.execute(
        "SELECT description FROM Catalog WHERE productname = ?", (productname,)).fetchone()[0]


# RU: Взять цену продукта из таблицы Catalog
# EU: Take the product price from the Catalog table
def get_product_price(productname):
    return cursor.execute(
        "SELECT price FROM Catalog WHERE productname = ?", (productname,)).fetchone()[0]
