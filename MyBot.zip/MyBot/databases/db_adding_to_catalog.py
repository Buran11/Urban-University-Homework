from texts import txt_products_info
from databases import db_catalog_orm as catalog


# RU: Добавление продуктов в каталог (Таблицу Catalog)
# EU: Adding products to the catalog (Catalog table)
def adding_to_catalog():
    catalog.add_product(
        txt_products_info.name_store_1000, txt_products_info.description_store_1000, txt_products_info.price_store_1000)
    catalog.add_product(
        txt_products_info.name_store_2500, txt_products_info.description_store_2500, txt_products_info.price_store_2500)
    catalog.add_product(
        txt_products_info.name_store_4000, txt_products_info.description_store_4000, txt_products_info.price_store_4000)
    catalog.add_product(
        txt_products_info.name_plus_3, txt_products_info.description_plus_3, txt_products_info.price_plus_3)
    catalog.add_product(
        txt_products_info.name_plus_12, txt_products_info.description_plus_12, txt_products_info.price_plus_12)
